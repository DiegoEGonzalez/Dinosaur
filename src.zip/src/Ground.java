/**
 * Created with IntelliJ IDEA.
 * User: Filmmakernow
 * Date: 5/22/14
 * Time: 8:43 AM
 * To change this template use File | Settings | File Templates.
 */
public class Ground extends Terrain {
    public Ground(){
        super("src/floor.png",500);
    }
}
