import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public abstract class Player {
    double x=0;
    double y=0;
    int h=0;
    int w=0;
    int angle=0;
    int xDirection=0;
    int yDirection=0;
    double speed=0;
    BufferedImage img = null;
    boolean alive = false;
    double scale = 1;

    public Player(String location){
        try{
            //Declares the img as the one in location
            img = ImageIO.read(new File(location));
            h=img.getHeight();
            w=img.getWidth();
        }catch (IOException e){
            e.printStackTrace();
        }
        alive = true;
    }

    public void update(){
         x+=(xDirection*speed)-((double)World.speed);
         y+=yDirection*speed;
    }
    public void move(int xDirection, int yDirection){
        this.xDirection=xDirection;
        this.yDirection=yDirection;
    }
    public void draw(Graphics g){
        BufferedImage shown = img;
        AffineTransform alter = new AffineTransform();
        alter.scale(scale,scale);
        //alter.rotate(angle,w/2,h/2);

        //AffineTransformOp op = new AffineTransformOp(alter,AffineTransformOp.TYPE_BILINEAR);
        //shown = op.filter(img,null);
        Graphics2D hi = (Graphics2D)g;
        hi.setTransform(alter);
        hi.drawImage(shown,(int)Math.round(x/scale),(int)Math.round(y),null);
    }

    public boolean isAlive(){
        return alive;
    }

}
