
public class Stage1 extends World{
    Stage1(){
        super();
    }
}
