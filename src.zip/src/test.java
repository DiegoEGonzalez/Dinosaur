
public class test extends Player {

    test(){

        super("src/Dino2.png");
        speed=.001;
        scale=2;
        y=150;
    }

}
