import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public abstract class World {
    public static double speed = .0001;
    double x=0;
    double y=0;
    int h=0;
    int w=0;
    BufferedImage back= null;
    BufferedImage floor= null;
    ArrayList<Terrain> bottom = new ArrayList<Terrain>();

    public World(){
        for(int x=0;x<1100;x+=100){
            bottom.add(new Ground());
            bottom.get(x/100).x=x;
        }
    }
    public void update(){
        for(Terrain a: bottom){
            a.update();
            if(a.x<-100)
            a.x=1000;
        }

    }
    public void draw(Graphics g){
        int tempx=(int)Math.round(x);
        for(Terrain a: bottom){
            a.draw(g);
        }
    }
}
