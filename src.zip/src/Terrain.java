import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public abstract class Terrain {
  double x;
  double y;
  BufferedImage img = null;
  int h;
  int w;

  public Terrain(String location, int y){
      try{
          img = ImageIO.read(new File(location));
          h=img.getHeight();
          w=img.getWidth();
      }catch (IOException e){
          e.printStackTrace();
      }
      this.y=y;
  }

  public void update(){
        x-=World.speed;
  }

  public void draw(Graphics g){
      g.drawImage(img,(int)Math.round(x),(int)Math.round(y),null);
  }
}
